import express from 'express'
import mongoose from 'mongoose'
import studentModel from './models/SRegister.js'
import enquiryModel from './models/Enquiry.js'
import contactModel from './models/Contact.js'
import enquiriesschema from './models/Enquiries.js'
import cors from 'cors'
// import Enquiries from '../Front-end/school-sphere/src/Enquiries.jsx'

const app = express()
app.use(cors())
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/School_spheredb").then(() => console.log("MongoDB connected")).catch(err => console.error("MongoDB connection error:", err));

// Student APIs
app.post("/addstudent",(req,res)=>{
    console.log("Student data:", req.body)
    studentModel.create(req.body).then(response=>res.json(response)).catch(err=>res.json(err))
})

app.get("/allstudents",(req,res)=>{
    studentModel.find().then(response=>res.json(response)).catch(err=>res.json(err))
})

// to show details of one student
app.get("/student/:id",(req,res)=>{
    const id = req.params.id
    studentModel.findById({_id:id}).then(sres=>res.json(sres)).catch(err=>res.json(err))
})

// to update record of student
app.put("/updatestudent/:id",(req,res)=>{
    const id = req.params.id
    studentModel.findByIdAndUpdate({_id:id}, req.body).then(sres=>res.json(sres)).catch(err=>res.json(err))
})

// to delete record of student
app.delete("/deletestudent/:id",(req,res)=>{
    const id =req.params.id;
    studentModel.findByIdAndDelete({_id:id}).then(result=>res.json(result)).catch(err=>res.json(err))
})

// Enquiry APIs
app.post("/addenquiry",(req,res)=>{
    console.log("Enquiry data:", req.body)
    enquiryModel.create(req.body).then(response=>res.json(response)).catch(err=>res.json(err))
})

app.get("/allenquiries",(req,res)=>{
    enquiryModel.find().then(response=>res.json(response)).catch(err=>res.json(err))
})

// to show details of one enquiry
app.get("/enquiry/:id",(req,res)=>{
    const id = req.params.id
    enquiryModel.findById({_id:id}).then(eres=>res.json(eres)).catch(err=>res.json(err))
})

// to delete enquiry
app.delete("/deleteenquiry/:id",(req,res)=>{
    const id =req.params.id;
    enquiryModel.findByIdAndDelete({_id:id}).then(result=>res.json(result)).catch(err=>res.json(err))
})

// Enquiries APIs
app.post("/addenquires",(req,res)=>{
    enquiriesschema.create(req.body).then(response=>res.json(response)).catch(err=>res.json(err))
})

app.get("/allenquires",(req,res)=>{
    enquiriesschema.find().then(response=>res.json(response)).catch(err=>res.json(err))
})

// to show details of one enquires
app.get("/enquires/:id",(req,res)=>{
    const id = req.params.id
    enquiriesschema.findById({_id:id}).then(eres=>res.json(eres)).catch(err=>res.json(err))
})

// to update record of enquires
app.put("/updateenquires/:id",(req,res)=>{
    const id = req.params.id
    enquiriesschema.findByIdAndUpdate({_id:id}, req.body).then(eres=>res.json(eres)).catch(err=>res.json(err))
})

// to delete enquires
app.delete("/deleteenquires/:id",(req,res)=>{
    const id =req.params.id;
    enquiriesschema.findByIdAndDelete({_id:id}).then(result=>res.json(result)).catch(err=>res.json(err))
})
// Contact APIs
app.post("/addcontact",(req,res)=>{
    console.log("Contact data:", req.body)
    contactModel.create(req.body).then(response=>res.json(response)).catch(err=>res.json(err))
})

app.get("/allcontacts",(req,res)=>{
    contactModel.find().then(response=>res.json(response)).catch(err=>res.json(err))
})

// to show details of one contact
app.get("/contact/:id",(req,res)=>{
    const id = req.params.id
    contactModel.findById({_id:id}).then(cres=>res.json(cres)).catch(err=>res.json(err))
})

// to update record of contact
app.put("/updatecontact/:id",(req,res)=>{
    const id = req.params.id
    contactModel.findByIdAndUpdate({_id:id}, req.body).then(cres=>res.json(cres)).catch(err=>res.json(err))
})

// to delete contact
app.delete("/deletecontact/:id",(req,res)=>{
    const id =req.params.id;
    contactModel.findByIdAndDelete({_id:id}).then(result=>res.json(result)).catch(err=>res.json(err))
})

app.listen(5000,()=>{
    console.log("Express server is started on port 5000")
})
