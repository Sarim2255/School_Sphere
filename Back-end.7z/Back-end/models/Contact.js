import mongoose from 'mongoose'

const contactSchema = new mongoose.Schema({
    fullName: String,
    email: String,
    message: String,
    createdAt: { type: Date, default: Date.now }
})
const contactModel = mongoose.model("contact", contactSchema)
export default contactModel;
