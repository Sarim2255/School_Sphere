import mongoose from 'mongoose'

const senq = new mongoose.Schema({
    name: String,
    email: String,
    mob: String,
    msg: String,
})
const enquiriesschema = mongoose.model("enquiries", senq)
export default enquiriesschema;
