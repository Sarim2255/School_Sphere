import mongoose from 'mongoose'

const studentSchema = new mongoose.Schema({
    name: String,
    age: Number,
    gender: String,
    contact: String,
    email: String,
    class: String
})
const studentModel = mongoose.model("student", studentSchema)
export default studentModel;
