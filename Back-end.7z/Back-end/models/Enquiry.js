import mongoose from 'mongoose'

const enquirySchema = new mongoose.Schema({
    parentName: String,
    studentName: String,
    email: String,
    phone: String,
    grade: String,
    enquiryType: String,
    message: String,
    createdAt: { type: Date, default: Date.now }
})
const enquiryModel = mongoose.model("enquiry", enquirySchema)
export default enquiryModel;
